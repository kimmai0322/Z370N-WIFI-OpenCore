# Z370N-wifi-OC-0.5.9
1.此efi文件为纯核显版本
2.视频输出接口请用DP或者HDMI2.0接口 HDMI接口暂时没有修复
3.本efi根据OC-0.5.9版本源文件进行修改，根据OpenCore Guide Book规则进行创建
4.请根据自身实际情况进行修改后使用，三码请务必进行修改！！！

other detail:https://github.com/kimmai0322/Z370N-WIFI-OpenCore/blob/master/README_CN.txt

opencore guide book:https://dortania.github.io/OpenCore-Desktop-Guide/
